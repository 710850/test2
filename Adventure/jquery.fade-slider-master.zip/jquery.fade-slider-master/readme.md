# jQuery.fade-slider

jQuery fade slider is a simple fade effect slider can auto resize .

## doc & demo

<a href="http://html5beta.com/jquery-2/jquery-fade-slider/">jquery.fade-slider</a>

## license

MIT